module.exports = { uiHost: '127.0.0.1', uiPort: 1880, flowFilePretty: true };
